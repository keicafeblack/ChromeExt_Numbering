/**
 * background.js
 * Handles the extension icon click event.
 */

// Save default settings when the extension is installed or updated.
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({
    labelFontSize: 12,
    labelOpacity: 0.8,
    labelColor: '#333333' // Default: dark gray
  });
});

// Fired when the extension icon (Action) is clicked.
chrome.action.onClicked.addListener(async (tab) => {
  if (tab.id) {
    try {
      // Send a message to the content.js script in the active tab.
      await chrome.tabs.sendMessage(tab.id, {
        action: "toggleNumbering"
      });
    } catch (e) {
      if (e.message.includes('Could not establish connection')) {
        // Expected error if clicked on a page where the content script
        // is not injected (e.g., chrome://extensions).
      } else {
        console.error(e);
      }
    }
  }
});