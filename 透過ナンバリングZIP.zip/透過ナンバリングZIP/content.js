/**
 * content.js
 * Injected into web pages to handle drawing and control of numbering.
 */

let numberingVisible = false;
let numberingContainer = null;
const NUMBERING_ID = 'transparent-numbering-container';
let redrawTimer; // Timer for debouncing (performance optimization)

// Object to hold default settings and loaded values
let numberingSettings = {
  labelFontSize: 12,
  labelOpacity: 0.8,
  labelColor: '#333333'
};

/**
 * Creates the container for labels and sets up event listeners
 */
function createAndShowNumbering() {
  if (!numberingContainer) {
    numberingContainer = document.createElement('div');
    numberingContainer.id = NUMBERING_ID;
    document.body.appendChild(numberingContainer);
    
    // Redraw on window resize or scroll
    window.addEventListener('resize', debounceRedraw);
    window.addEventListener('scroll', debounceRedraw);
  }

  redrawNumbering();
  numberingContainer.style.display = 'block';
  numberingVisible = true;
}

/**
 * Hides the numbering and removes event listeners
 */
function hideNumbering() {
  if (numberingContainer) {
    numberingContainer.style.display = 'none';
  }
  window.removeEventListener('resize', debounceRedraw);
  window.removeEventListener('scroll', debounceRedraw);
  numberingVisible = false;
}

/**
 * Executes the redraw function only once, 100ms after the last resize/scroll event
 * to avoid excessive calls.
 */
function debounceRedraw() {
  clearTimeout(redrawTimer);
  redrawTimer = setTimeout(redrawNumbering, 100);
}

/**
 * Scans the page elements and draws the numbering labels
 */
function redrawNumbering() {
  if (!numberingContainer) return;

  numberingContainer.innerHTML = ''; // Clear all existing labels

  // 1. Get target elements (fields and buttons)
  const fields = Array.from(document.querySelectorAll(
    'input:not([type="hidden"]):not([type="button"]):not([type="submit"]):not([type="reset"]):not([type="image"]):not([type="radio"]):not([type="checkbox"]), ' +
    'textarea, select'
  ));
  const buttons = Array.from(document.querySelectorAll(
    'button, a[href], input[type="button"], input[type="submit"], input[type="reset"], [role="button"]'
  ));

  // Collect in one DOM element array
  const allElements = [...fields, ...buttons];

  // 2. Filter only elements visible in the viewport and sort them from top-to-bottom, left-to-right
  const visibleElements = allElements
    .filter(el => isElementVisibleInViewport(el)) 
    .sort((a, b) => {
      const rectA = a.getBoundingClientRect(); 
      const rectB = b.getBoundingClientRect(); 
      
      // First, sort by Y coordinate (top) (elements higher up come first)
      if (rectA.top !== rectB.top) {
        return rectA.top - rectB.top;
      }
      
      // If Y coordinates are the same, sort by X coordinate (left) (elements further left come first)
      return rectA.left - rectB.left; 
    });

  // 3. Determine label style from settings
  const hex = numberingSettings.labelColor.replace('#', '');
  const r = parseInt(hex.substring(0, 2), 16);
  const g = parseInt(hex.substring(2, 4), 16);
  const b = parseInt(hex.substring(4, 6), 16);
  const labelBgColor = `rgba(${r}, ${g}, ${b}, ${numberingSettings.labelOpacity})`;
  // Auto-select text color (white or black) based on background brightness
  const labelTextColor = (r * 0.299 + g * 0.587 + b * 0.114) > 186 ? '#000000' : '#ffffff';

  // Numbering with a unified counter
  let counter = 1; 

  // 4. Apply labels to the sorted elements
  for (const el of visibleElements) { 
    const rect = el.getBoundingClientRect(); 
    const label = document.createElement('span');
    label.className = 'numbering-label';

    // Use the counter value directly as text
    let labelText = String(counter++); 
    label.textContent = labelText;

    // Set style (considering page scroll)
    // Adjust label position to the top-left of the element
    label.style.left = `${window.scrollX + rect.left - 24}px`; 
    label.style.top = `${window.scrollY + rect.top - 8}px`; 
    label.style.fontSize = `${numberingSettings.labelFontSize}px`;
    label.style.backgroundColor = labelBgColor;
    label.style.color = labelTextColor;

    numberingContainer.appendChild(label);
  }
}

/**
 * Checks if an element is visible in the viewport and not hidden by styles.
 * @param {HTMLElement} el - The element to check
 * @returns {boolean} true if visible
 */
function isElementVisibleInViewport(el) {
  const rect = el.getBoundingClientRect();

  // Exclude elements off-screen or with zero size
  if (rect.width === 0 || rect.height === 0 || rect.bottom < 0 || rect.right < 0 || rect.top > window.innerHeight || rect.left > window.innerWidth) {
    return false;
  }

  const style = window.getComputedStyle(el);
  if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0' || style.pointerEvents === 'none') {
    return false;
  }

  // Traverse parent elements to check if any are hidden
  let parent = el.parentElement;
  while (parent) {
    const parentStyle = window.getComputedStyle(parent);
    if (parentStyle.display === 'none' || parentStyle.visibility === 'hidden') {
      return false;
    }
    if (parent === document.body) {
      break;
    }
    parent = parent.parentElement;
  }

  return true;
}


// Listener for messages from background.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "toggleNumbering") {
    if (numberingVisible) {
      hideNumbering();
    } else {
      // Load the latest settings before showing
      chrome.storage.sync.get(numberingSettings, (items) => {
        numberingSettings = items;
        createAndShowNumbering();
      });
    }
  }
});

// Listener to monitor setting changes and apply them in real-time if visible
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'sync') {
    let settingsChanged = false;
    for (let key in changes) {
      if (numberingSettings.hasOwnProperty(key)) {
        numberingSettings[key] = changes[key].newValue;
        settingsChanged = true;
      }
    }
    if (settingsChanged && numberingVisible) {
      redrawNumbering();
    }
  }
});