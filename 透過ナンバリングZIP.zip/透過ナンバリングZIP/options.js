/**
 * options.js
 * Logic for the options page.
 */

// Saves options from the form to chrome.storage
function saveOptions() {
  const labelFontSize = document.getElementById('labelFontSize').value;
  const labelOpacity = document.getElementById('labelOpacity').value;
  const labelColor = document.getElementById('labelColor').value;

  chrome.storage.sync.set({
    labelFontSize: Number(labelFontSize),
    labelOpacity: Number(labelOpacity),
    labelColor: labelColor
  }, () => {
    // Update status to let user know options were saved.
    const status = document.getElementById('status');
    status.textContent = 'Settings saved.';
    setTimeout(() => {
      status.textContent = '';
    }, 1500);
  });
}

// Restores options from chrome.storage to the form.
function restoreOptions() {
  // Set default values.
  chrome.storage.sync.get({
    labelFontSize: 12,
    labelOpacity: 0.8,
    labelColor: '#333333'
  }, (items) => {
    document.getElementById('labelFontSize').value = items.labelFontSize;
    document.getElementById('labelOpacity').value = items.labelOpacity;
    document.getElementById('labelOpacityValue').textContent = items.labelOpacity;
    document.getElementById('labelColor').value = items.labelColor;
  });
}

// Set event listeners
document.addEventListener('DOMContentLoaded', restoreOptions);
document.getElementById('save').addEventListener('click', saveOptions);

// Logic to display the slider value in real-time
const opacitySlider = document.getElementById('labelOpacity');
const opacityValue = document.getElementById('labelOpacityValue');
opacitySlider.addEventListener('input', () => {
  opacityValue.textContent = opacitySlider.value;
});